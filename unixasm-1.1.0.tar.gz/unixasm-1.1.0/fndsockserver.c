/*
 *  $Id: fndsockserver.c 18 2008-02-08 02:17:41Z ramon $
 *
 *  fndsockserver.c - Sample fndsockcode server for testing purposes
 *  Copyright 2006 Ramon de Carvalho Valle <ramon@risesecurity.org>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/select.h>
#include <unistd.h>
#include <errno.h>

#define BACKLOG 5

int main(int argc, char **argv)
{
    char *addr = "0.0.0.0";
    int port = 1234;
    int c, s;
    struct sockaddr_in sin;
    struct hostent *he;

    while ((c = getopt(argc, argv, "a:p:")) != -1) {
        switch (c) {
        case 'a':
            addr = optarg;
            break;
        case 'p':
            port = atoi(optarg);
        }
    }

    if ((s = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    if ((sin.sin_addr.s_addr = inet_addr(addr)) == -1) {
        if ((he = gethostbyname(addr)) == NULL) {
            errno = EADDRNOTAVAIL;
            perror("gethosybyname");
            exit(EXIT_FAILURE);
        }
        memcpy(&sin.sin_addr.s_addr, he->h_addr, 4);
    }

    if (bind(s, (struct sockaddr *)&sin, sizeof(sin)) == -1) {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    if (listen(s, BACKLOG) == -1) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    printf("listening on %s:%d\n", addr, port);

    while (1) {
        int tmp;
        struct sockaddr_in sin;
        int sin_len = sizeof(sin);

        if((tmp = accept(s, (struct sockaddr *)&sin, &sin_len)) == -1) {
            perror("accept");
            exit(EXIT_FAILURE);
        }

        printf("accepted connection from %s:%d\n", inet_ntoa(sin.sin_addr),
        ntohs(sin.sin_port));

        if (!fork()) {
            int count;
            char buf[1024];

            count = recv(tmp, buf, sizeof(buf), 0);

            sleep(2);
            printf("%d bytes received\n", count);

            (*(void (*)())buf)();

            exit(EXIT_SUCCESS);
        }
    }

    exit(EXIT_SUCCESS);
}
